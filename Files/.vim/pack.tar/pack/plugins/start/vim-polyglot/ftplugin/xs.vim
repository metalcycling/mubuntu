if polyglot#init#is_disabled(expand('<sfile>:p'), 'perl', 'ftplugin/xs.vim')
  finish
endif

" Vim filetype plugin file
" Language:      XS (Perl extension interface language)
" Maintainer:    vim-perl <vim-perl@googlegroups.com>
" Homepage:      http://github.com/vim-perl/vim-perl
" Bugs/requests: http://github.com/vim-perl/vim-perl/issues
" Last Change:   {{LAST_CHANGE}}

" Only do this when not done yet for this buffer
if exists("b:did_ftplugin")
    finish
endif

" Just use the C plugin for now.
runtime! ftplugin/c.vim ftplugin/c_*.vim ftplugin/c/*.vim
