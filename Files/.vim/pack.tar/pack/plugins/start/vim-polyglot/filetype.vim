runtime! ftdetect/polyglot.vim
